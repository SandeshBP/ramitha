import React, { Component } from 'react';
import {incrementCount,decrementCount}from "../actions/counterActions"
import { connect } from 'react-redux';
class Counter extends Component {
  render() {
      const {count,incrementCount,decrementCount}=this.props
    return (
    <div>
            <span>{count}</span>
            <button className="btn btn-success" onClick={()=>incrementCount()}>+</button>&nbsp;
            <button className="btn btn-warning" onClick={()=>decrementCount()}>-</button>

      </div>
    );
  }
}
const mapStateToProps=(state)=>({
    count:state
})

const mapDispatchToProps=(dispatch)=>({
    incrementCount:()=>{dispatch(incrementCount())},
    decrementCount:()=>{dispatch(decrementCount())}
   
})  
  export default connect( mapStateToProps,mapDispatchToProps)(Counter)
  

  