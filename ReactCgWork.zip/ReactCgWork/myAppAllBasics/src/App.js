import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Welcome from './components/homes'
import Employee from './components/functionalComponent'
import Greatings from './components/Greetings';
import GreatingsClass from './components/GreetingsClass';
import NumListClass from './components/numListClass';
import UserMap from './components/usermap';
import EventBind from './components/eventBind';
import AgeUpdate from './components/eventForUpdateAge';
import StateDemo from './components/stateDemo'
import {BrowserRouter as Router,Route,Link,Switch} from 'react-router-dom'
import Home from './components/Home'
import About from './components/About'
import PageNF from './components/PageNotFound';
import Nav1 from './components/NavDemo';
import form from './components/form';
import Form2 from './components/form2';
import FormEg from './components/inlinestyle';
import focusUsingRefs from './components/refsDemo';
import CustomerInfo from './components/customer-info';
import ViewContact from './components/viewContact';
import ShowContact from './components/showContact';
import AddContact from './components/addContact';
import Image from './components/lab1';



class App extends Component {
  render() {
    let numArray=[1,2,3,4,5,6,7,8,9]
    let user={
      name:"Sandesh",
      age:20,
      hobies:["Sports","Music"]
    }
     return (
    
      // <div className="container">
      // <div className="row">
      // <div className="col-lg-12">
      // <BrowserRouter>
      //   <div>
      //     <ul>
      //       <li>
      //         <Link to ='/'>Home</Link>
      //       </li>
      //       <li>
      //         <Link to ='/about'>About</Link>
      //       </li>
          
      //     </ul>
      //  <div>
      //   <Switch>
      //     <Route exact path="/" component={Home}/>
      //     <Route exact path="/about" component={About}/>
      //     <Route exact path="/*" component={PageNF}/>

      //   </Switch> 
      //   </div>
      //     </div>
      // </BrowserRouter>
      // </div>
      // </div>
      // </div>
//====================================================================================
       <Router>
         <div>
           <Nav1/>
           <div className="container">
             <Switch>
               <Route exact path="/" component={Home} />
               <Route exact path="/about" component={About} />
               <Route exact path="/form" component={form} />
               <Route exact path="/form2" component={Form2} />
               <Route exact path="/inlinestyle" component={FormEg} />
               <Route exact path="/refsDemo" component={focusUsingRefs} />
               <Route exact path="/customer-info" component={CustomerInfo} />
               <Route exact path="/viewContact" component={ViewContact} />
               <Route exact path="/displayImage" component={Image} />

               {/* <Route exact path="/showContact" component={ShowContact} />
               <Route exact path="/addContact" component={AddContact} />
 */}
             </Switch>
           </div>
         </div>
       </Router>
    );
  }
}

export default App;

















    //   <div className="App">
    //     <header className="App-header">
    //       <img src={logo} className="App-logo" alt="logo" />
    //       <p>
    //         Edit <code>src/App.js</code> and save to reload.
    //       </p>
    //       <a
    //         className="App-link"
    //         href="https://reactjs.org"
    //         target="_blank"
    //         rel="noopener noreferrer"
    //       >
    //         Learn React
    //       </a>
    //     </header>
    //   </div>
    // <div>
    //       <h1>Hello welcome to my app</h1>
    //       {/* <h1>This is other tag</h1> */}
    //       <Welcome/>
    //     {/* <Employee/> */}
    //     <button className="btn btn-danger">Danger</button>
    //     <Greatings/>
    // </div>
//=============================================================================================
      // <div className="container">
      //  <div className="row">    
      //      <div className="col-xs-12">
      //      {/* <Greatings name="sandesh"/>  
      //      <Greatings name="Sindu"/>     
      //      <hr />  
      //       <GreatingsClass name='Sandesh '/>
      //       <hr>
      //       </hr>
      //       <NumListClass numArray={numArray}/>
      //       <hr>
      //       </hr>
      // <UserMap user={user}>This is user details</UserMap>
      //           <hr/>
      //       <EventBind></EventBind> */}
      //       <AgeUpdate age={32}></AgeUpdate>
      //       <hr></hr>
      //       <StateDemo  message="welcome Guest"></StateDemo>
      //       <StateDemo counter={0}></StateDemo>

      //           </div>
      //           </div>
      //           </div>
//=================================================================================================

     