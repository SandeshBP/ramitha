import React,{Component} from 'react'
class Form extends Component{
    constructor(props){
        super(props);
        this.state={
            firstname:"",
            lastname:"",
            topic:'Angular'
        }
    }
    handleSubmit=(event)=>{
        alert(`${this.state.firstname}`)
        console.log(this.state.firstname)
        console.log(this.state.lastname)
        console.log(this.state.topic)
        event.preventDefault()

        
    }
    handleChangeFirstName=(event)=>{
        this.setState({
            firstname:event.target.value
        })
    }
    handleChangeLastName=(event)=>{
        this.setState({
            lastname:event.target.value
        })
    }
    handleChangetopic=(event)=>{
        this.setState({
            topic:event.target.value
        })
    }

    render(){
        return(
            <div>
           <h3>Form Demo</h3>
           <form onSubmit={this.handleSubmit}>
               <div>
                   <label>First Name</label>
                    <input type="text" value={this.state.firstname} onChange={this.handleChangeFirstName} />
               </div>
               <div>
                   <label>Last Name</label>
                    <input type="text" value={this.state.lastname}  onChange={this.handleChangeLastName}/>
               </div>
               <div>
                   <label>Topic</label>
                    <select value={this.state.topic} onChange={this.handleChangetopic}>
                        <option value="Angular">Angular</option>
                        <option value="node">Node</option>
                        <option valve="rect">React</option>

                    </select>
                       </div>
                       <button type="submit">submit</button>
           </form>

           </div>
        )
    }
}
export default  Form