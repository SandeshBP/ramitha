import React,{Component} from 'react'

class Home extends Component{
    render(){
   
        return(
            <div>
                <h1>Hello from home component</h1>
                <img src={require('./download.jfif')}/>
            </div>
       
        )
    }
}

export default  Home