import React,{Component} from 'react'
import { compileFunction } from 'vm';

class NumListClass extends Component{
    render(){
        return(
            <div>
                 <ul>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>

            </ul>
            
            {this.props.numArray.map((n)=><li>{n}</li>)}
               
            
               

           

            </div>
           
        )
    }
}
export default NumListClass