import React,{Component} from 'react'
class EventBind extends Component{
     callEvent(){
            console.log("I'm from eventBinding ")
        }
        render(){
       
        return(
            <div>
            <button className="btn btn-success" onClick={()=>this.callEvent()}>click event</button>
            </div>
        )
    }
}

export default EventBind