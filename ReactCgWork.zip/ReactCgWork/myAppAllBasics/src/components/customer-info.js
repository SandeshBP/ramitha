import React,{Component} from 'react'
import ShowCustomer from './showCustomer';


class CustomerInfo extends Component{
    constructor(){
        super()
        this.state={
            user:{
                userName:'',
                userEmail:'',
                userMobile:'',
                userAddress:'',
                userDescription:'',
                userDateOfVisit:'',
            },
            dispUser:false
        }
    }
    handleSubmit(event){ 
         event.preventDefault();      
        // alert(`${this.state.user.userName}`)
        // alert(`${this.state.user.userEmail}`)
        // alert(`${this.state.user.userMobile}`)
        // alert(`${this.state.user.userAddress}`)
        // alert(`${this.state.user.userDescription}`)
        // alert(`${this.state.user.userDateOfVisit}`)
        // console.log(this.state.user)
        this.setState({dispUser:true})
    }
    updateState(ctrl,value){
        const {user}=this.state
        user[ctrl]=value
        this.setState({user})
    }
    resetState(){
        console.log('sas')
        // this.resetState({user})
        this.setState({
            user:{
                userName:'',
                userEmail:'',
                userMobile:'',
                userAddress:'',
                userDescription:'',
                userDateOfVisit:'',
            }
            
        })

    }

    render(){
   const {user}=this.state
        return(
            <div>
            <h1>State add and delete</h1>
            <form onSubmit={(event)=>this.handleSubmit(event)} >
            <div>
                <label>User Name</label>
                 <input type="text" value={user.userName} onChange={(e)=>{this.updateState('userName',e.currentTarget.value)}}/>
            </div>
            <div>
                <label>Email </label>
                 <input type="text" value={user.userEmail} onChange={(e)=>{this.updateState('userEmail',e.currentTarget.value)}}/>
            </div>
            <div>
                <label>Mobile </label>
                 <input type="text" value={user.userMobile} onChange={(e)=>{this.updateState('userMobile',e.currentTarget.value)}}/>
            </div>
            <div>
                <label> Address</label>
                 <input type="text" value={user.userAddress} onChange={(e)=>{this.updateState('userAddress',e.currentTarget.value)}}/>
            </div><div>
                <label>Description </label>
                 <input type="text" value={user.userDescription} onChange={(e)=>{this.updateState('userDescription',e.currentTarget.value)}}/>
            </div><div>
                <label>User date of Visit </label>
                 <input type="text" value={user.userDateOfVisit} onChange={(e)=>{this.updateState('userDateOfVisit',e.currentTarget.value)}}/>
            </div>
            <div>
                </div>
                <button type="submit">submit</button>
                </form>
               {
                   this.state.dispUser?<ShowCustomer 
                userData={this.state.user} 
                deleteCustomer={()=>this.resetState()}></ShowCustomer>:null
               }
                
            </div>
            
        )
    }
}

export default  CustomerInfo