import React, { Component } from 'react'
import AddContact from './addContact';
import ShowContact from './showContact';
import axios from 'axios';

class ViewContact extends Component {
    state = { contact: [] }


    baseUrl = "http://localhost:3000/contacts"

    getAllContacts=()=>{
        axios.get(this.baseUrl).then((response) => {
            this.setState({ contact: response.data })
        })
    }
    addContacts=(contact)=>{
        alert('1')
        axios.post(this.baseUrl, contact).then((response)=>{
            this.getAllContacts();
            alert('contactAdded');
        }
        )
    }

    deleteContacts=(id)=>{
       
        axios.delete(this.baseUrl+"/"+id).then((response)=>{
            this.getAllContacts();
             alert(id);
        }
        )
    }

    componentDidMount() { this.getAllContacts() }

    render() {
        return (
            <div>
                <h1>  Manage contact </h1>

                <AddContact addContact={(contact) => this.addContacts(contact)}></AddContact>
                <ShowContact contacts={this.state.contact}
                deleteContact={(id) => this.deleteContacts(id)}></ShowContact>

            </div>

        )
    }
}

export default ViewContact