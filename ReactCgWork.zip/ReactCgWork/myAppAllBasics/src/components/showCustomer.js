import React,{Component} from 'react'

class ShowCustomer extends Component{
    render(){
        const user =this.props.userData
   
        return(
            <div>
                <h1>User Details</h1>
                <p>User Name : {user.userName}</p>
                <p>User Email : {user.userEmail}</p>
                <p>User Mobile : {user.userMobile}</p>
                <p>User Address : {user.userAddress}</p>
                <p>User Description : {user.userDescription}</p>
                <p>User Date of Visit : {user.userDateOfVisit}</p>
                <button onClick={ ()=>this.props.deleteCustomer()}>Delete User</button>

            </div>
        )
    }
}

export default  ShowCustomer