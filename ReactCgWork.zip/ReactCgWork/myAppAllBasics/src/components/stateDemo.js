import React,{Component} from 'react'
class StateDemo extends Component{
    constructor(props){
        super(props)
        this.state=[{message:this.props.message},{counter:parseInt(this.props.counter)}]

    }
    changeState(){
        this.setState({ message:"Namaskara Sandesh "});

        
    }
changeStateCounter(){
    let prevCtr=this.state.counter
    console.log(this.state.counter)
    console.log(prevCtr)
    this.setState({  counter:prevCtr});
      

}


        render(){
       
        return(
            <div>  
                 <h1> {this.state.message}</h1>
                 <button className="btn btn-primary" onClick={()=>this.changeState()}>Update State</button>
                <p>{this.state.message}</p>
                <p> current state: {this.state.counter}</p>
                <button className="btn btn-success" onClick={()=>this.changeStateCounter()}>
                Update Counter</button>

            </div>
         
        )
    }
}

export default StateDemo