import React,{Component} from 'react'

class Welcome extends Component{
    render(){
        let msg="Hello freinds"
        let msg1="Hell freinds"


        return(
            <div>
            <h1>Hello from home component</h1>
            <p>{2+2}</p>
            <p>{msg}</p>
           </div>
        )
    }
}

export default  Welcome