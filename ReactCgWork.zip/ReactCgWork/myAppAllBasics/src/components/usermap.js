import React,{Component} from 'react'
class UserMap extends Component{
    render(){
        return(
            <div>
                <p>{this.props.children}</p>
                <p>Name: {this.props.user.name}</p>
                <p>Age: {this.props.user.age}</p>
            {this.props.user.hobies.map((n)=><li>{n}</li>)}
            </div>
        )
    }
}

export default UserMap