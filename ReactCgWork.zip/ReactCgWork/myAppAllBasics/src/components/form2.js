import React,{Component} from 'react'
class Form2 extends Component{
    constructor(props){
        super(props);
        this.state={
            firstname:"",
            dispName:"",
         
        }
    }
    

    handleChangeFirstName=(event)=>{
        this.setState({
                    firstname:event.target.value

        })  
    }
    handleSubmit=(event)=>{
        this.setState({
       dispName:this.state.firstname   
   }) 
   event.preventDefault()
}
    render(){
        return(
            <div>
           <h3>Form Demo</h3>
           <h1>{this.state.dispName.toUpperCase()}</h1>

           <form onSubmit={this.handleSubmit}>
               <div>
                   <label>First Name</label>
                    <input type="text" value={this.state.firstname} onChange={this.handleChangeFirstName} />
               </div>
              
              
                       <button type="submit">submit</button>
           </form>

           </div>
        )
    }
}
export default  Form2