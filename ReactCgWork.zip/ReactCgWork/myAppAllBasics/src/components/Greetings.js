import React,{Component} from 'react'

const Greatings=(props)=>{
    return <h1>Hello {props.name}</h1>
}

export default Greatings