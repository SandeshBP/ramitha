import React, { Component } from 'react'

class ShowContact extends Component {
    render() {

        return (
            <div>
                <h1>  Show contact </h1>
                <table className='table table-bordered table-responsive'>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Contact Number</th>
                        </tr>
                    </thead>

                    <tbody >
                        {this.props.contacts.map((n) =>
                            <tr key={n}>
                                <td>{n.contactName} </td>
                                <td>{n.contactNumber} </td>
                                <td> 
                                    <button className="btn btn-danger" 
                                    onClick={()=>this.props.deleteContact(n.id)} >X</button>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>


            </div>

        )
    }
}

export default ShowContact