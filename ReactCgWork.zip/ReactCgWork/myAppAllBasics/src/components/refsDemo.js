import React,{Component} from 'react'

class focusUsingRefs extends Component{
    constructor(){
        super()
        this.focusRef=React.createRef();
    }
    componentDidMount(){
        this.focusRef.current.focus();
        console.log(this.focusRef   )
    }
    render(){
   
        return(
       <div>
           <div>
                    <input type="text" ref={this.focusRef} /> 
                    <button type="submit">Click</button>

               </div>
              
              
       </div>
        )
    }
}

export default  focusUsingRefs