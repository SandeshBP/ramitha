import React,{Component} from 'react'
class AgeUpdate extends Component{
    // constructor(props){
    //     super();
    //     this.age=props.age
    // }
     callEvent(){
         let age=this.props.age
         console.log("age before update "+age)
        age+=5
        console.log("age after update "+age)
        this.age=age

        // console.log("age before update "+this.age)

        //  this.age+=5
        //     console.log("age after update "+this.age)
        }
        render(){
       
        return(
            <div>
            <button className="btn btn-primary" onClick={()=>this.callEvent()}>Update age</button>
            
            <p>Age after Update :{this.age}</p>

            </div>
        )
    }
}

export default AgeUpdate