import React,{Component} from 'react'

class AddContact extends Component{
    // constructor(){
    //     this.state={contactsend:{
    //         contactName:'',
    //         contactNumber:""
    //     },
    // }
    
    contactname=React.createRef()
    contactnumber=React.createRef()
    handleEvent=()=>{
        alert('hai')
           let contObj={
               contactName: this.contactname.current.value,
               contactNumber:this.contactnumber.current.value
            //    contactName:this.contactname.current.value,
            //    contactNumber:this.contactnumber.current.value
           }
           alert('hi')
           this.props.addContact(contObj)

            
        }

    render(){
   
        return(
            <div>
                <h1>  Add contact </h1>
                <form  >
                    <label>contactName</label>
                    <input  ref={this.contactname}/>
                    <label>Number </label> 
                    <input ref={this.contactnumber}/>
                <button className="btn btn-primary"  onClick={this.handleEvent}>Add</button>
                </form>
            </div>
       
        )
    }
}

export default  AddContact



// onClick={()=>this.props.addContact(this.state.contactsend)}