import React,{Component} from 'react'

const Employee=()=> {
    return <h1> this is from functional component </h1>
    
}

export default Employee