import React,{Component} from 'react'

class About extends Component{
    render(){
     

        return(
            
            <h1>Hello from About component</h1>
        
        )
    }
}

export default  About