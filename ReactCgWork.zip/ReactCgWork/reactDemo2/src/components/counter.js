import React, { Component } from 'react';
import { connect } from 'react-redux';


class Counter extends Component {
    render() {
        let prop = this.props

        return (
            <div>
                <h3>Counter</h3>
                <p>Count:{this.props.count}</p>
                <button onClick={this.props.onIncrementClick}>Increment</button>
            </div>
        );
    }
}

function mapStateToProps(state) {
    console.log('mapStateToProps', state)
    return {
        count: state.count
    }
}

function mapDispatchToProps(dispatch){
    return{
        onIncrementClick:()=>{
            console.log('clicking')
           const action ={type:'INCREMENT'}
           dispatch(action)
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Counter);
