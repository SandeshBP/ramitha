import {createStore} from 'redux'
const initialSate={
    count:3
}
const reducer=(state=initialSate,action)=>{
    console.log('reducer running',action)
    switch(action.type){
        case 'INCREMENT':  return Object.assign({},state,{count:state.count+1})

    }
    return state

}

const store=createStore(reducer);

export default store;