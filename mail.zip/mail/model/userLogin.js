var mong=require('mongoose');


const userLoginSchema=new mong.Schema({

      
    id:{
        type:String,
        required:false
    },
    firstName:{
        type:String,    
        required:false
    },
    lastName:{
        type:String,
        required:false
    },
    phoneNumber:{
        type:Number,
        required:false
    },
    email:{
        type:String,
        required:false
    },
    password:{
        type:String,
        required:false
    }

  
});

const userLogs=module.exports=mong.model('register',userLoginSchema)