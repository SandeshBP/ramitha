var express = require('express')
const nodemailer = require("nodemailer");
var router=express.Router();
var UserLogs=require('../model/userLogin')

//=========================================================
router.get('/',(req,res)=>{
    console.log('am from router module')
})

//=========================================================
// // //register.......................................
router.post("/register", (req, res) => {
    console.log("request came");
    let user = new UserLogs(req.body);
    
    sendMail(user, info => {
      console.log(`The mail has beed send 😃 and the id is ${info.messageId}`);
      res.send(info);
    });
  });
  //func to send mail
  async function sendMail(user) {
      let testAccount = await nodemailer.createTestAccount();
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        service:'gmail',
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user:"sandeshbplotlikar@gmail.com", // generated ethereal user
       pass: "Sand9215"
      }
       
    });

    //mailing format
    let mailOptions = {
        from: '"Fun Of Heuristic"<example.gimail.com>', // sender address
        to: "saiteja31096@gmail.com", // list of receivers
        subject: "Wellcome to Fun Of Heuristic 👻", // Subject line
        html: `<h1>Hi ${user.firstName}</h1><br>
        <h4>Thanks for joining us</h4>`
      };
    
      // send mail with defined transport object
      let info = await transporter.sendMail(mailOptions,(error,info)=>{
          if(error){
              console.log(error)
          }
          else{
              console.log("email sent"+info.response)
          }
      });
    
      
    }

// // main().catch(console.error);
  //========================================================
//   async function main(){

//     // Generate test SMTP service account from ethereal.email
//     // Only needed if you don't have a real mail account for testing
//     let testAccount = await nodemailer.createTestAccount();
  
//     // create reusable transporter object using the default SMTP transport
//     let transporter = nodemailer.createTransport({
//       host: "smtp.ethereal.email",
//       port: 520,
//       secure: false, // true for 465, false for other ports
//       auth: {
//         user: testAccount.user, // generated ethereal user
//         pass: testAccount.pass // generated ethereal password
//       }
//     });
  
//     // send mail with defined transport object
//     let info = await transporter.sendMail({
//       from: '"Fred Foo 👻" <foo@example.com>', // sender address
//       to: "sandehbplotlikar@gmail.com", // list of receivers
//       subject: "Hello ✔", // Subject line
//       text: "Hello world?", // plain text body
//       html: "<b>Hello world?</b>" // html body
//     });
  
//     console.log("Message sent: %s", info.messageId);
//     // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
  
//     // Preview only available when sending through an Ethereal account
//     console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
//     // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
//   }
  
//   main().catch(console.error);



module.exports=router;