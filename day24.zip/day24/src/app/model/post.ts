export class Post{

  postedBy:string
   post:String
   likes:Number
   dislikes:Number
   comments:[{
     commentedBy:String,
     comment:String,
   }]
 

    }