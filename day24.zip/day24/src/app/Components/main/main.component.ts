import { Component, OnInit } from "@angular/core";
import { Post } from "src/app/model/post";
import { UserRegService } from "src/app/Services/user-reg.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-main",
  templateUrl: "./main.component.html",
  styleUrls: ["./main.component.css"]
})
export class MainComponent implements OnInit {
  loggedUserId = localStorage.getItem("loggedUserId");
  postIt: Post;
  constructor(private userRegService: UserRegService, private router: Router) {}

  ngOnInit() {
    if (this.loggedUserId) {
    } else {
      this.router.navigate(["userlogin"]);
    }
  }

  post(post) {
    this.postIt.post = post;
    // this.postIt.postedBy=
  }
}
