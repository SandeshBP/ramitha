import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-network',
  templateUrl: './my-network.component.html',
  styleUrls: ['./my-network.component.css']
})
export class MyNetworkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
