import { Component, OnInit } from "@angular/core";
import { UserRegService } from "src/app/Services/user-reg.service";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
@Component({
  selector: "app-login",

  templateUrl: "./user-login.component.html",

  styleUrls: ["./user-login.component.css"]
})
export class UserLoginComponent implements OnInit {
  loginForm: FormGroup;
  loginResponse={
    msg:"",
    email:"",
    password:""
  }
  submitted: boolean = false;

  constructor(private userRegService: UserRegService, private router: Router) {}

  ngOnInit() {
    this.loginForm = new FormGroup({
      email: new FormControl("", [
        Validators.required,

        Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,3}$")
      ]),

      password: new FormControl("", [Validators.required])
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    } else {
      this.userRegService.login(this.loginForm.value).subscribe(data => {
        
        this.loginResponse=data
        console.log(( this.loginResponse));
        if(this.loginResponse.msg=="Success")
        this.router.navigate(["userHome"]);
      });
    }
  }
}
