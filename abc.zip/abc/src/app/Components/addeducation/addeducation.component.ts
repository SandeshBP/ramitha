import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addeducation',
  templateUrl: './addeducation.component.html',
  styleUrls: ['./addeducation.component.css']
})
export class AddeducationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
