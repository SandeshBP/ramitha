import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-org-signup',
  templateUrl: './org-signup.component.html',
  styleUrls: ['./org-signup.component.css']
})
export class OrgSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
