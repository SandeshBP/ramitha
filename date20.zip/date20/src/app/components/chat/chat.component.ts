import { Component, OnInit } from '@angular/core';
import { UserServiceService } from 'src/app/UserService/user-service.service';
import {User, Message} from "src/app/model/user-model"
@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  user:User[];
  msg:Message=new Message()
  receiverId:Number
  senderId=parseInt(localStorage.getItem("loggedUserId"));
  messsageArray:Message[]=[]
  displayMsgArray:Message[]=[]
  date=new Date()
  constructor(    private userService: UserServiceService
    ) { }

  ngOnInit() {
    this.userService.getUser().subscribe(data => { this.user
      = this.user=data.filter(u=> u.firstName!==localStorage.getItem("loggedUserName"));
 
      })



  }
  idStore(id){
this.receiverId=id
console.log(id)
localStorage.setItem('receiverId',id)
console.log(this.receiverId)
this.receiverId=parseInt(localStorage.getItem("receiverId"))
this.displayMessage()
  }
  sendMsg(message){
    this.msg.msg=message;
    this.msg.sender=parseInt(localStorage.getItem("loggedUserId"));
    this.msg.receiver=this.receiverId;
    this.msg.TimeNdate=this.date
    console.log(this.msg.receiver)

this.userService.storeMsg(this.msg).subscribe(data=>{this.idStore(this.receiverId)})
    this.idStore(this.receiverId)
  }


  displayMessage(){
    this.displayMsgArray=[]
this.userService.retriveMsg().subscribe(data=>{this.messsageArray=data;

for(let varMessage of this.messsageArray){
  console.log("i am displaying "+varMessage.receiver+" "+this.receiverId)
  console.log(this.receiverId +"msg obj" + varMessage.receiver)
    if((varMessage.sender==this.senderId && varMessage.receiver==this.receiverId)||
    (varMessage.sender==this.receiverId && varMessage.receiver==this.senderId)){
      
  console.log(varMessage.msg)
      this.displayMsgArray.push(varMessage)
    }
  }

  console.log(this.displayMsgArray)}) 
  
 }

}
