
export class User{
    id:number
    firstName:string
    lastName:string
    phoneNumber:number
    email:string
    password:string
}
export class Message{
    sender:number
    receiver:Number
    msg:string
    TimeNdate:Date
    id?:number
   
}